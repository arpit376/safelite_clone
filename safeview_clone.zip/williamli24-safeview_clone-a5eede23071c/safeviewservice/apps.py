from django.apps import AppConfig


class SafeviewserviceConfig(AppConfig):
    name = 'safeviewservice'
